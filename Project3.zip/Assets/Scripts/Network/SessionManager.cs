public static class SessionManager
{
    public static string Token;
}