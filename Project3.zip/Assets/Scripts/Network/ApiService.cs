using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Networking;

public class ApiService : MonoBehaviour
{
    private string baseUrl = "http://localhost:3000/api";

    // LOGIN
    public void Login(string userCode, string pin, Action<LoginResponse> onSuccess, Action<string> onError)
    {
        StartCoroutine(LoginCoroutine(userCode, pin, onSuccess, onError));
    }

    private IEnumerator LoginCoroutine(string userCode, string pin, Action<LoginResponse> onSuccess, Action<string> onError)
    {
        string url = baseUrl + "/auth/login";

        string json = $"{{\"userCode\":\"{userCode}\",\"pin\":\"{pin}\"}}";

        var req = new UnityWebRequest(url, "POST");
        byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(json);

        req.uploadHandler = new UploadHandlerRaw(bodyRaw);
        req.downloadHandler = new DownloadHandlerBuffer();

        req.SetRequestHeader("Content-Type", "application/json");

        yield return req.SendWebRequest();

        if (req.result != UnityWebRequest.Result.Success)
        {
            onError?.Invoke("Login error");
            yield break;
        }

        var response = JsonUtility.FromJson<LoginResponse>(req.downloadHandler.text);
        onSuccess?.Invoke(response);
    }

    // GET LOANS
    public void GetLoans(string sort, string order, Action<LoansResponse> onSuccess, Action<int> onError)
    {
        StartCoroutine(GetLoansCoroutine(sort, order, onSuccess, onError));
    }

    private IEnumerator GetLoansCoroutine(string sort, string order, Action<LoansResponse> onSuccess, Action<int> onError)
    {
        string url = $"{baseUrl}/loans?sort={sort}&order={order}";

        var req = UnityWebRequest.Get(url);

        req.SetRequestHeader("Authorization", "Bearer " + SessionManager.Token);

        yield return req.SendWebRequest();

        if (req.responseCode == 401)
        {
            onError?.Invoke(401);
            yield break;
        }

        if (req.result != UnityWebRequest.Result.Success)
        {
            onError?.Invoke(500);
            yield break;
        }

        var data = JsonUtility.FromJson<LoansResponse>(req.downloadHandler.text);
        onSuccess?.Invoke(data);
    }

    // LOGOUT
    public void Logout(Action onSuccess)
    {
        StartCoroutine(LogoutCoroutine(onSuccess));
    }

    private IEnumerator LogoutCoroutine(Action onSuccess)
    {
        string url = baseUrl + "/auth/logout";

        var req = new UnityWebRequest(url, "POST");

        req.downloadHandler = new DownloadHandlerBuffer();
        req.uploadHandler = new UploadHandlerRaw(System.Text.Encoding.UTF8.GetBytes("{}"));

        req.SetRequestHeader("Authorization", "Bearer " + SessionManager.Token);
        req.SetRequestHeader("Content-Type", "application/json");

        yield return req.SendWebRequest();

        SessionManager.Token = null;

        onSuccess?.Invoke();
    }
}