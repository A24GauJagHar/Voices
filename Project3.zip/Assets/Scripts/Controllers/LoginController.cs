using UnityEngine;
using UnityEngine.UIElements;

public class LoginController : MonoBehaviour
{
    [SerializeField] private UIDocument doc;
    [SerializeField] private ApiService api;

    private void Start()
    {
        var root = doc.rootVisualElement;

        var userCode = root.Q<TextField>("UserCode");
        var pin = root.Q<TextField>("Pin");
        var btn = root.Q<Button>("LoginBtn");
        var error = root.Q<Label>("ErrorLabel");

        btn.clicked += () =>
        {
            api.Login(
                userCode.value,
                pin.value,
                (res) =>
                {
                    SessionManager.Token = res.token;

                    FindObjectOfType<LoansController>().Show();
                    gameObject.SetActive(false);
                },
                (err) =>
                {
                    error.text = "Login incorrecte";
                }
            );
        };
    }
}