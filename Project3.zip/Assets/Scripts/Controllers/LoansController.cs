using UnityEngine;
using UnityEngine.UIElements;

public class LoansController : MonoBehaviour
{
    [SerializeField] private UIDocument doc;
    [SerializeField] private ApiService api;
    [SerializeField] private VisualTreeAsset itemTemplate;

    private VisualElement root;
    private ScrollView list;

    public void Show()
    {
        gameObject.SetActive(true);
        LoadLoans("title", "asc");
    }

    private void Start()
    {
        root = doc.rootVisualElement;

        list = root.Q<ScrollView>("LoansList");

        var sort = root.Q<DropdownField>("SortDropdown");
        var order = root.Q<DropdownField>("OrderDropdown");

        var refresh = root.Q<Button>("RefreshBtn");
        var logout = root.Q<Button>("LogoutBtn");

        refresh.clicked += () =>
        {
            LoadLoans(sort.value, order.value);
        };

        logout.clicked += () =>
        {
            api.Logout(() =>
            {
                SessionManager.Token = null;
                FindObjectOfType<LoginController>().gameObject.SetActive(true);
                gameObject.SetActive(false);
            });
        };
    }

    void LoadLoans(string sort, string order)
    {
        api.GetLoans(sort, order,
            (data) =>
            {
                list.Clear();

                foreach (var loan in data.loans)
                {
                    var item = itemTemplate.CloneTree();

                    item.Q<Label>("Title").text = loan.title;
                    item.Q<Label>("Author").text = loan.author;
                    item.Q<Label>("Days").text = loan.daysLeft.ToString();

                    var card = item.Q<VisualElement>("Card");

                    if (loan.daysLeft >= 3)
                        card.style.backgroundColor = Color.green;
                    else if (loan.daysLeft >= 0)
                        card.style.backgroundColor = Color.yellow;
                    else
                        card.style.backgroundColor = Color.red;

                    list.Add(item);
                }
            },
            (error) =>
            {
                if (error == 401)
                {
                    FindObjectOfType<LoginController>().gameObject.SetActive(true);
                    gameObject.SetActive(false);
                }
            });
    }
}