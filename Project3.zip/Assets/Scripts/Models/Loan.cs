using System;

[Serializable]
public class Loan
{
    public int loanId;
    public string title;
    public string author;
    public string loanDate;
    public string dueDate;
    public int daysLeft;
}