using System;

[Serializable]
public class LoginResponse
{
    public string token;
    public User user;
}

[Serializable]
public class User
{
    public int id;
    public string name;
}