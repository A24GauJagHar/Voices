using System;

[Serializable]
public class LoansResponse
{
    public int userId;
    public Loan[] loans;
}