using UnityEngine;
using UnityEngine.UIElements;
public class MenuController : MonoBehaviour
{
    [SerializeField] private UIDocument menuDocument;
    [SerializeField] private NetworkManager networkManager;
    private VisualElement root;
    private Label label;
    void Start()
    {
        root = menuDocument.rootVisualElement;
        Button btnHello = root.Q<Button>("BtnHello");
        Button btnUser = root.Q<Button>("BtnUser");
        label = root.Q<Label>("DebugLabel");
        btnHello.clicked += () =>
        {
            label.text = "Sending hello request...";
            networkManager.TestRequest(
                onSuccess: (response) =>
                {
                    label.text = "Server says:\n" + response;
                },
                onError: (error) =>
                {
                    label.text = "Error:\n" + error;
                }
            );
        };

        btnUser.clicked += () =>
        {
            label.text = "Requesting random user...";
            networkManager.GetUserData(
                onSuccess: (user) =>
                {
                    label.text =
                    $"User received\nName: {user.name}\nAge: {user.age}";
                },
                onError: (error) =>
                {
                    label.text = "Error:\n" + error;
                }
            );
        };
    }
}