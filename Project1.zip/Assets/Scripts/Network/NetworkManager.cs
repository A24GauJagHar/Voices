using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
public class NetworkManager : MonoBehaviour
{
    [Header("Endpoints")]
    [SerializeField] private string helloUrl = "http://localhost:3000/hello";
    [SerializeField] private string userUrl = "http://localhost:3000/user";
    public void TestRequest(Action<string> onSuccess = null, Action<string> onError = null)
    {
        StartCoroutine(SendGetRequest(helloUrl, onSuccess, onError, responseText => responseText));
    }
    public void GetUserData(Action<UserData> onSuccess = null, Action<string> onError = null)
    {
        StartCoroutine(SendGetRequest(userUrl, onSuccess, onError, JsonUtility.FromJson<UserData>));
    }
    private IEnumerator SendGetRequest<T>(string url, Action<T> onSuccess, Action<string> onError, Func<string, T> responseParser)
    {
        Debug.Log($"Sending GET request to: {url}");
        using (UnityWebRequest request = UnityWebRequest.Get(url))
        {
            yield return request.SendWebRequest();
            if (request.result != UnityWebRequest.Result.Success)
            {
                Debug.LogError($"Request error to {url}: {request.error}");
                onError?.Invoke(request.error);
                yield break;
            }
            string responseText = request.downloadHandler.text;
            Debug.Log($"Response from {url}: {responseText}");
            try
            {
                T data = responseParser(responseText);
                if (System.Collections.Generic.EqualityComparer<T>.Default.Equals(data, default))
                {
                    var errorMessage = $"Failed to parse response from {url}";
                    Debug.LogError(errorMessage);
                    onError?.Invoke(errorMessage);
                    yield break;
                }
                onSuccess?.Invoke(data);
            }
            catch (Exception e)
            {
                var errorMessage = $"Error processing response from {url}: {e.Message}";
                Debug.LogError(errorMessage);
                onError?.Invoke(errorMessage);
            }
        }
    }
}