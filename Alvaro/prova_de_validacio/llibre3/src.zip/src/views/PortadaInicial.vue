<template>
  <v-container class="text-center mt-10">
    <h1>Benvingut a la Biblioteca!</h1>
    <p>Aquesta és la portada inicial de la teva aplicació.</p>

    <v-btn class="mt-4" color="primary" to="/llibres">
      Veure llibres
    </v-btn>
  </v-container>
</template>

<script setup>
</script>
