const fs = require('fs').promises;
const fsSync = require('fs');
const readline = require('readline');

async function inicialitzarAplicacio() {
  console.log('=== SeriesTracker v2.0 - Processament Avançat ===\n');
  try {
    await crearDirectori('data');
    await crearDirectori('logs');
    await crearDirectori('backups');
    await crearDirectori('informes');
    await crearDirectori('import');
    console.log('✓ Estructura de directoris verificada');
    await crearFitxerSiNoExisteix('logs/activitat.log', '');
    await escriureLog('Sistema inicialitzat amb noves funcionalitats');
    console.log('✓ Sistema inicialitzat correctament\n');
  } catch (error) {
    console.log(' Error inicialitzant aplicació:', error.message);
  }
}

async function crearDirectori(nomDirectori) {
  try {
    await fs.mkdir(nomDirectori, { recursive: true });
  } catch (error) {
    if (error.code !== 'EEXIST') console.log(' Error creant directori:', error.message);
  }
}

async function crearFitxerSiNoExisteix(rutaFitxer, contingutInicial) {
  try {
    await fs.access(rutaFitxer);
  } catch {
    await fs.writeFile(rutaFitxer, contingutInicial, 'utf8');
  }
}

async function crearConfiguracio(nomUsuari) {
  const dataActual = new Date().toISOString();
  const contingut = `Usuari: ${nomUsuari}
Data inici: ${dataActual}
Sèries seguides: 0`;
  try {
    await fs.writeFile('data/config.txt', contingut, 'utf8');
    await escriureLog(`Configuració creada per ${nomUsuari}`);
    console.log(`✓ Configuració creada per: ${nomUsuari}`);
  } catch (error) {
    console.log(' Error creant configuració:', error.message);
  }
}

async function afegirSerie(titolSerie, numTemporades, estatVisualitzacio) {
  const liniaSerie = `${titolSerie} - ${numTemporades} temporades - Estat: ${estatVisualitzacio}\n`;
  try {
    await crearBackup('series.txt');
    await fs.appendFile('data/series.txt', liniaSerie, 'utf8');
    await actualitzarComptadorSeries();
    await escriureLog(`Sèrie '${titolSerie}' afegida`);
    console.log(`✓ Sèrie '${titolSerie}' afegida correctament`);
  } catch (error) {
    console.log(' Error afegint sèrie:', error.message);
  }
}

async function mostrarConfiguracio() {
  console.log('--- Configuració d\'usuari ---');
  try {
    const contingut = await fs.readFile('data/config.txt', 'utf8');
    console.log(contingut);
    console.log('');
  } catch {
    console.log(' Fitxer de configuració no trobat\n');
  }
}

async function llegirSeries() {
  console.log('--- Llistant sèries ---');
  try {
    const contingut = await fs.readFile('data/series.txt', 'utf8');
    if (contingut.trim()) console.log(contingut);
    else console.log('No hi ha sèries registrades.');
    console.log('');
  } catch {
    console.log('No hi ha sèries registrades.\n');
  }
}

async function crearBackup(nomFitxer) {
  const rutaOriginal = `data/${nomFitxer}`;
  const ara = new Date();
  const nomBackup = `${nomFitxer.replace('.txt', '')}_backup_${ara.getFullYear()}-${(ara.getMonth() + 1)
    .toString()
    .padStart(2, '0')}-${ara.getDate().toString().padStart(2, '0')}_${ara.getHours()
    .toString()
    .padStart(2, '0')}-${ara.getMinutes().toString().padStart(2, '0')}.txt`;
  const rutaBackup = `backups/${nomBackup}`;
  try {
    await fs.access(rutaOriginal);
    await fs.copyFile(rutaOriginal, rutaBackup);
    await escriureLog(`Backup creat: ${rutaBackup}`);
  } catch {}
}

async function escriureLog(missatge) {
  const timestamp = new Date().toISOString();
  const entradaLog = `[${timestamp}] INFO: ${missatge}\n`;
  try {
    await fs.appendFile('logs/activitat.log', entradaLog, 'utf8');
  } catch (error) {
    console.log(' Error escrivint log:', error.message);
  }
}

async function actualitzarComptadorSeries() {
  try {
    const contingut = await fs.readFile('data/config.txt', 'utf8');
    const linies = contingut.split('\n');
    let numSeries = 0;
    try {
      const seriesContingut = await fs.readFile('data/series.txt', 'utf8');
      const liniesNoVuides = seriesContingut.split('\n').filter(linia => linia.trim() !== '');
      numSeries = liniesNoVuides.length;
    } catch {
      numSeries = 0;
    }
    linies[2] = `Sèries seguides: ${numSeries}`;
    await fs.writeFile('data/config.txt', linies.join('\n'), 'utf8');
  } catch (error) {
    console.log(' Error actualitzant comptador:', error.message);
  }
}

async function analitzarLogs() {
  console.log('--- Analitzant logs d\'activitat ---');
  console.log(' Processant logs/activitat.log...');
  try {
    const rl = readline.createInterface({
      input: fsSync.createReadStream('logs/activitat.log'),
      crlfDelay: Infinity
    });
    let totalLinies = 0, operacionsInfo = 0, operacionsError = 0, numSeriesAfegides = 0, backupsCreats = 0;
    for await (const linia of rl) {
      totalLinies++;
      if (totalLinies % 100 === 0) console.log(` Processades ${totalLinies} línies...`);
      if (linia.includes('] INFO:')) {
        operacionsInfo++;
        if (linia.includes('afegida')) numSeriesAfegides++;
        if (linia.includes('Backup creat')) backupsCreats++;
      } else if (linia.includes('] ERROR:')) operacionsError++;
    }
    console.log(' Anàlisi completada!\n');
    console.log(' ESTADÍSTIQUES DE LOGS:');
    console.log(` Total entrades: ${totalLinies}`);
    console.log(` Operacions INFO: ${operacionsInfo}`);
    console.log(` Errors trobats: ${operacionsError}`);
    console.log(` Sèries afegides: ${numSeriesAfegides}`);
    console.log(` Backups creats: ${backupsCreats}\n`);
    await escriureLog(`Anàlisi de logs completada: ${totalLinies} entrades`);
    return { totalLinies, operacionsInfo, operacionsError, seriesAfegides: numSeriesAfegides, backupsCreats };
  } catch (error) {
    console.log(' Error analitzant logs:', error.message);
    return null;
  }
}

async function crearFitxerImportacio() {
  console.log(' Creant fitxer d\'exemple per importació...');
  const contingutSeriesPopulars = `Breaking Bad|5|Completada
Game of Thrones|8|Completada
The Office|9|Completada
Stranger Things|4|En curs
Friends|10|Completada
The Sopranos|6|Completada
Lost|6|Completada
House|8|Completada
Sherlock|4|Completada
The Wire|5|Completada
Mad Men|7|Completada
Dexter|8|Completada
True Detective|3|En curs
Fargo|4|En curs
Better Call Saul|6|Completada
Westworld|4|Pendent
The Crown|6|En curs
House of Cards|6|Completada
Orange Is the New Black|7|Completada
Narcos|3|Completada
Mindhunter|2|Pendent
The Witcher|3|En curs
Money Heist|5|Completada
Dark|3|Completada
Chernobyl|1|Completada
Band of Brothers|1|Completada
Vikings|6|Completada
Peaky Blinders|6|Completada
Boardwalk Empire|5|Completada
The Mandalorian|3|En curs`;
  try {
    await fs.writeFile('import/series_populars.txt', contingutSeriesPopulars, 'utf8');
    console.log('✓ Fitxer import/series_populars.txt creat amb 30 sèries\n');
    await escriureLog('Fitxer d\'importació creat amb sèries populars');
  } catch (error) {
    console.log(' Error creant fitxer d\'importació:', error.message);
  }
}

async function importarSeries() {
  console.log('--- Importació de sèries populars ---');
  console.log(' Important des d\'import/series_populars.txt...');
  try {
    try {
      await fs.access('import/series_populars.txt');
    } catch {
      await crearFitxerImportacio();
    }

    const rl = readline.createInterface({
      input: fsSync.createReadStream('import/series_populars.txt'),
      crlfDelay: Infinity
    });

    let totalProcessades = 0, numSeriesImportades = 0;
    const titolSeriesExistents = [];
    try {
      const contingutExistent = await fs.readFile('data/series.txt', 'utf8');
      const liniesExistents = contingutExistent.split('\n');
      for (const linia of liniesExistents) {
        if (linia.trim() !== '') titolSeriesExistents.push(linia.split(' - ')[0]);
      }
    } catch {}

    await crearBackup('series.txt');

    for await (const linia of rl) {
      totalProcessades++;
      if (totalProcessades % 10 === 0) console.log(` Processades ${totalProcessades} línies...`);
      if (linia.trim() !== '') {
        const parts = linia.split('|');
        if (parts.length === 3) {
          const [titolSerie, numTemporades, estatVisualitzacio] = parts;
          if (!titolSeriesExistents.includes(titolSerie)) {
            const liniaSerieFormatada = `${titolSerie} - ${numTemporades} temporades - Estat: ${estatVisualitzacio}\n`;
            await fs.appendFile('data/series.txt', liniaSerieFormatada, 'utf8');
            numSeriesImportades++;
            titolSeriesExistents.push(titolSerie);
          }
        }
      }
    }

    await actualitzarComptadorSeries();
    console.log(` Importades ${numSeriesImportades} sèries noves de ${totalProcessades} processades\n`);
    await escriureLog(`Sèries importades: ${numSeriesImportades} de ${totalProcessades}`);

    return { importades: numSeriesImportades, processades: totalProcessades };
  } catch (error) {
    console.log(' Error important sèries:', error.message);
    return { importades: 0, processades: 0 };
  }
}

async function generarInformeDiari(estadistiquesLogs, estadistiquesImportacio) {
  console.log('--- Generant informe diari ---');
  console.log(' Creant informes/informe_diari.txt...');
  try {
    const writeStream = fsSync.createWriteStream('informes/informe_diari.txt', { encoding: 'utf8' });
    const dataActual = new Date().toISOString();
    let nomUsuari = 'Usuari desconegut', dataInici = 'Data desconeguda', totalSeries = 0;
    try {
      const configuracio = await fs.readFile('data/config.txt', 'utf8');
      const liniesConfig = configuracio.split('\n');
      nomUsuari = liniesConfig[0].replace('Usuari: ', '');
      dataInici = liniesConfig[1].replace('Data inici: ', '');
      totalSeries = parseInt(liniesConfig[2].replace('Sèries seguides: ', ''));
    } catch {}
    let completades = 0, enCurs = 0, pendents = 0;
    try {
      const contingutSeries = await fs.readFile('data/series.txt', 'utf8');
      for (const linia of contingutSeries.split('\n')) {
        if (linia.includes('Estat: Completada')) completades++;
        else if (linia.includes('Estat: En curs')) enCurs++;
        else if (linia.includes('Estat: Pendent')) pendents++;
      }
    } catch {}
    writeStream.write('===================================\n');
    writeStream.write(' INFORME DIARI SERIESTRACKER\n');
    writeStream.write('===================================\n');
    writeStream.write(`Data: ${dataActual}\n`);
    writeStream.write(`Usuari: ${nomUsuari}\n`);
    writeStream.write(`Data inici sistema: ${dataInici}\n\n`);
    writeStream.write(' ESTADÍSTIQUES GENERALS:\n');
    writeStream.write(` Sèries en seguiment: ${totalSeries}\n`);
    writeStream.write(` Sèries completades: ${completades}\n`);
    writeStream.write(` Sèries en curs: ${enCurs}\n`);
    writeStream.write(` Sèries pendents: ${pendents}\n\n`);
    if (estadistiquesLogs) {
      writeStream.write(' ACTIVITAT DEL SISTEMA:\n');
      writeStream.write(` Total operacions: ${estadistiquesLogs.totalLinies}\n`);
      writeStream.write(` Operacions exitoses: ${estadistiquesLogs.operacionsInfo}\n`);
      writeStream.write(` Errors del sistema: ${estadistiquesLogs.operacionsError}\n`);
      writeStream.write(` Sèries afegides: ${estadistiquesLogs.seriesAfegides}\n`);
      writeStream.write(` Backups creats: ${estadistiquesLogs.backupsCreats}\n\n`);
    }
    if (estadistiquesImportacio) {
      writeStream.write(' IMPORTACIONS:\n');
      writeStream.write(` Sèries importades: ${estadistiquesImportacio.importades}\n`);
      writeStream.write(` Fitxers processats: ${estadistiquesImportacio.processades} línies\n\n`);
    }
    writeStream.write('===================================\nGenerat automàticament per SeriesTracker v2.0\n===================================\n');
    writeStream.end();
    writeStream.on('finish', () => console.log(' Informe generat correctament\n'));
    writeStream.on('error', e => console.log(' Error generant informe:', e.message));
    await escriureLog('Informe diari generat correctament');
  } catch (error) {
    console.log(' Error generant informe:', error.message);
  }
}

async function main() {
  try {
    await inicialitzarAplicacio();
    console.log('--- Verificant sistema existent ---');
    try {
      await fs.access('data/config.txt');
      await mostrarConfiguracio();
    } catch {
      console.log('Creant configuració inicial...');
      await crearConfiguracio('Joan Garcia');
      console.log('');
    }
    let hiHaSeries = false;
    try {
      const seriesExistents = await fs.readFile('data/series.txt', 'utf8');
      if (seriesExistents.trim().length > 0) hiHaSeries = true;
    } catch {}
    if (!hiHaSeries) {
      console.log('--- Afegint sèries d\'exemple ---');
      await afegirSerie('Breaking Bad', 5, 'Completada');
      await afegirSerie('Stranger Things', 4, 'En curs');
      await afegirSerie('The Office', 9, 'Pendent');
      console.log('');
    }
    await llegirSeries();
    console.log(' Executant noves funcionalitats de la Sessió 2...\n');
    const estadistiquesLogs = await analitzarLogs();
    const estadistiquesImportacio = await importarSeries();
    await generarInformeDiari(estadistiquesLogs, estadistiquesImportacio);
    console.log('=== Processament completat ===');
    console.log(' S\'han executat totes les funcionalitats de les sessions 1 i 2');
    console.log(' Pots revisar els resultats a:');
    console.log(' - data/series.txt (sèries actualitzades)');
    console.log(' - informes/informe_diari.txt (informe generat)');
    console.log(' - logs/activitat.log (registre d\'activitats)');
    console.log(' - backups/ (còpies de seguretat)');
    await escriureLog('Sessió completa - totes les funcionalitats executades');
  } catch (error) {
    console.log(' Error en l\'aplicació principal:', error.message);
    await escriureLog(`ERROR: ${error.message}`);
  }
}

main().catch(error => {
  console.error(' Error crític en l\'aplicació:', error);
  process.exit(1);
});
