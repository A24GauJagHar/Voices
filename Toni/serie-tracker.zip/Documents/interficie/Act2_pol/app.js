import express from "express";
import { v4 as uuidv4 } from 'uuid';
const app = express();
app.use(express.json());


const PORT = 3000;


// Exemple de preguntes (en realitat les llegiríeu del fitxer JSON)
const preguntesBase = [
  { id: 1, question: "2+2?", answers: ["3", "4", "5"], correctAnswer: 1 },
  { id: 2, question: "Capital de França?", answers: ["Berlin", "Paris", "Madrid"], correctAnswer: 1 },
  { id: 3, question: "Color del cel?", answers: ["Blau", "Verd", "Vermell"], correctAnswer: 0 }
];


// Diccionari per sessions
const sessions = [];


// Ruta getPreguntes
app.post("/getPreguntes", (req, res) => {
  const num = parseInt(req.body?.num, 10) || 1;


  // Seleccionem preguntes a l'atzar
  const seleccionades = preguntesBase.sort(() => 0.5 - Math.random()).slice(0, num);


  const idUsuari = uuidv4();


  // Guardem respostes correctes
  sessions[idUsuari] = {
    correctes: seleccionades.map(p => p.correctAnswer)
  };


  // Enviem preguntes sense resposta correcta
  const senseCorrecta = seleccionades.map(p => ({
    id: p.id,
    question: p.question,
    answers: p.answers
  }));


  res.json({ idUsuari, preguntes: senseCorrecta });
});


// Ruta finalista
app.post('/finalista', (req, res) => {
  const { idUsuari, respostes } = req.body;


  const sessio = sessions[idUsuari];
  if (!sessio) {
    return res.status(400).json({ error: "Sessió no trobada" });
  }


  let correct = 0;
  let wrong = 0;
  sessio.correctes.forEach((c, i) => {
    if (respostes [i] === c){
      correct++;
    }  else {
      wrong++;
    }
  });


  res.json({
    correctes: correct ,
    wrongs: wrong,
    total: sessio.correctes.length
  });
});


app.listen(PORT, () => {
  console.log(`Servidor escoltant al port ${PORT}`);
});

