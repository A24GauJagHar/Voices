const express = require('express')
const app = express()
const port = 3000

const users = [
  { user: "harsh", password: "harsh1234", roles: ["administrador"] },
  { user: "joel", password: "joel1234", roles: ["client", "editor"] },
  { user: "pariskar", password: "pariskar1234", roles: ["editor"] },
]

app.get('/auth', (req, res) => {
  const { user, password } = req.query   

  const found = users.find(u => u.user === user && u.password === password)

  if (found) {
    res.json({ isAuth: true, roles: found.roles })
  } else {
    res.json({ isAuth: false, roles: [] })
  }
})

app.listen(port, () => {
  console.log(`Servidor escoltant al port ${port}`)
})