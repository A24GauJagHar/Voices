// Importem la llibreria "natural"
const natural = require("natural");
// Creem un analitzador de sentiments per a anglès (per defecte)
const Analyzer = natural.SentimentAnalyzer;
const stemmer = natural.PorterStemmer; // Redueix les paraules a l'arrel
const analyzer = new Analyzer("English", stemmer, "afinn");

// Frases de prova
const frases = [
  "This is my happy life.",
  "I loved that present",
  "This time will pass as well"
];

// Recorrem les frases i analitzem el sentiment
frases.forEach((frase) => {
  const score = analyzer.getSentiment(frase.split(" "));

  /*
    El resultat és un número:
    - Positiu → sentiment positiu
    - Negatiu → sentiment negatiu
    - Proper a 0 → neutre
  */
  console.log(`Frase: "${frase}"`);
  console.log(`Score: ${score}\n`);
});